# DesignPatterns-Examples

This code is adapted to C# by me, but orginaly made and presented on youtube on the following videaos

Factory - https://www.youtube.com/watch?v=ub0DXaeV6hA
by Derek Banas https://www.youtube.com/channel/UCwRXb5dUK4cvsHbx-rGzSgw

Facade - https://www.youtube.com/watch?v=B1Y8fcYrz5o
by Derek Banas https://www.youtube.com/channel/UCwRXb5dUK4cvsHbx-rGzSgw

Repository - https://www.youtube.com/watch?v=rtXpYpZdOzM
by Programming with Mosh https://www.youtube.com/channel/UCWv7vMbMWH4-V0ZXdmDpPBA

Decorator - https://www.youtube.com/watch?v=j40kRwSm4VE
by Derek Banas https://www.youtube.com/channel/UCwRXb5dUK4cvsHbx-rGzSgw

Template - https://www.youtube.com/watch?v=aR1B8MlwbRI
by Derek Banas https://www.youtube.com/channel/UCwRXb5dUK4cvsHbx-rGzSgw

Full PlayList with aditional patterns :
https://www.youtube.com/watch?v=vNHpsC5ng_E&list=PLF206E906175C7E07
