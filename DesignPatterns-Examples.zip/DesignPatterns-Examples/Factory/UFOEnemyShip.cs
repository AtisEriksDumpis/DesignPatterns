﻿namespace Factory
{
    public class UFOEnemyShip : EnemyShip
    {
        public UFOEnemyShip()
        {
            SetName("UFO Enemy Ship");
            SetDamage(20.0);
        }
    }
}
