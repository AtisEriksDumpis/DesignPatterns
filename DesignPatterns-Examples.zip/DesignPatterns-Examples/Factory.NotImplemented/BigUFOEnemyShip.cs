﻿using Factory.NotImplemented;

namespace Factory
{
    public class BigUFOEnemyShip : UFOEnemyShip
    {
    public BigUFOEnemyShip()
    {
        SetName("Big UFO Enemy Ship");
        SetDamage(40.0);
    }
    }
}
